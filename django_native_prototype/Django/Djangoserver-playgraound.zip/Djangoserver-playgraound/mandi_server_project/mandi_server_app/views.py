from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json

@csrf_exempt
def hello_response(request):
    if request.method == "POST":
        try:
            # Parse the incoming JSON data
            data = json.loads(request.body)

            # Extract the 'message' from the JSON payload
            message = data.get('message', '').lower()

            if message == "hello":
                response = "No hello"
            else:
                response = "Invalid message"
            
            return JsonResponse({"response": response})
        
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)

    return JsonResponse({"error": "Invalid request method"}, status=400)
