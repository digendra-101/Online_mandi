from django.urls import path
from .views import hello_response

urlpatterns = [
    path('hello/', hello_response, name='hello_response'),
]
